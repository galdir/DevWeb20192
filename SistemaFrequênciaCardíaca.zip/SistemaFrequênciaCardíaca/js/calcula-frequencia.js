var btnCalcular = document.querySelector("#calcular-freq");
btnCalcular.addEventListener("click", function (event) {
    event.preventDefault();

    var form = document.querySelector("#form-calcula");

    var dados = obterDados(form);
    console.log(dados);

    var validaUsuario = validacao(dados);
    console.log(validaUsuario);
    if (validaUsuario == true) {
        var info = document.querySelector(".exibir-result");

        var idade = calculaidade(dados.data);

        var freqMax = calcularFCM(idade);

        var feqalvo = calcularFCA(freqMax);

        info.style.display = "block";
        info.innerHTML = "Nome: " + dados.nome + "<br>Idade: " + idade + " anos! <br><br> Frequência cardíaca máxima: " + freqMax + "bpm. <br><br> " + feqalvo;

    } else {
        alert("Insira corretamente todos os campos");
    }
});
var btnVoltar = document.querySelector("#voltar");
btnVoltar.addEventListener("click", function(event){
    event.preventDefault();
    location.reload();
});
function obterDados(form) {
    var pessoa = {
        nome: form.nome.value,
        sobrenome: form.sobrenome.value,
        data: form.dataNasc.value
    }
    return pessoa;
}
function calculaidade(data) {
    var d = new Date(data);
    console.log(d);
    var dtAtual = new Date();
    console.log(dtAtual);
    var anoAtual = dtAtual.getFullYear();
    console.log(anoAtual);
    var niverEsteano = new Date(anoAtual, d.getMonth(), d.getDate());
    console.log(niverEsteano);
    var idade = anoAtual - d.getFullYear();
    console.log(idade);
    if (niverEsteano > dtAtual) {
        idade--;
    }
    return idade;
}
function calcularFCM(idade) {
    var fcm = 220 - idade;
    return fcm;
}
function calcularFCA(freqMax) {
    var fcaMenor = freqMax * 0.5;
    var fcaMaior = freqMax * 0.85;
    var result = "O intervalo entre suas frequências cardíacas alvo está entre " + fcaMenor + "bpm no mínimo e " + fcaMaior + "bpm no máximo."

    return result;
}
function validacao(dados) {
    var valid = false;
    if (dados.nome.value != "" && dados.sobrenome.value != "") {
        valid = true;
    } else {
        valid = false;
    }
    return valid;
}
